# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [9.0.1](https://github.com/serialport/node-serialport/compare/v9.0.0...v9.0.1) (2020-08-08)

**Note:** Version bump only for package serialport





# [9.0.0](https://github.com/serialport/node-serialport/compare/v8.0.8...v9.0.0) (2020-05-10)

**Note:** Version bump only for package serialport





## [8.0.8](https://github.com/serialport/node-serialport/compare/v8.0.7...v8.0.8) (2020-05-07)

**Note:** Version bump only for package serialport





## [8.0.7](https://github.com/serialport/node-serialport/compare/v8.0.6...v8.0.7) (2020-01-30)

**Note:** Version bump only for package serialport





## [8.0.6](https://github.com/serialport/node-serialport/compare/v8.0.5...v8.0.6) (2019-12-25)


### Bug Fixes

* stream required bindings-mock as a dep ([#1970](https://github.com/serialport/node-serialport/issues/1970)) ([e978b7e](https://github.com/serialport/node-serialport/commit/e978b7eb244b87a6be2ae914965adeb1f4562935))
