#ifndef PACKAGES_SERIALPORT_SRC_SERIALPORT_UNIX_H_
#define PACKAGES_SERIALPORT_SRC_SERIALPORT_UNIX_H_

int ToBaudConstant(int baudRate);
int ToDataBitsConstant(int dataBits);

#endif  // PACKAGES_SERIALPORT_SRC_SERIALPORT_UNIX_H_
