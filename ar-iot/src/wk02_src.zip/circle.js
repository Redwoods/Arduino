// cicle.js
var PI = Math.PI;
 
module.exports = function (r) {
    return PI * r * r;
};
 
module.exports = function (r) {
    return 2 * PI * r;
};
