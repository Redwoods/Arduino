// cicle.js
var PI = Math.PI;
 
module.exports.area = function (r) {
    return PI * r * r;
};
 
module.exports.circumference = function (r) {
    return 2 * PI * r;
};
