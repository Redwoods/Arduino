// circle_info.js : call module circle.js
var circle = require('');
console.log( 'The area of a circle of radius 4 is '
    + );
console.log( 'The circumference of a circle of radius 4 is '
    + );

