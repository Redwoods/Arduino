// circle_info.js
var circle = require('./circle.js');
console.log( 'The area of a circle of radius 4 is '
    + circle.area(4).toFixed(2));
console.log( 'The circumference of a circle of radius 4 is '
    + circle.circumference(4).toFixed(2));

