// tcp server (network server)
var net = require();
var port = 3000;

// Network connection using socket
var server = net.createServer(function(  ) {
	console.log("Connection from " + socket.);
	socket.end("Hello AA00! from localhost:3000");
});

server.(port, "127.0.0.1");
console.log("Network server started at port : " + port);
